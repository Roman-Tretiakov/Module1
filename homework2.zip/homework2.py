home_work_quantity = 12
spent_hour = 1.5
course_name = 'Python'
average_spent_time = spent_hour / home_work_quantity

print('Курс:', f'{course_name},', 'всего задач:', f'{home_work_quantity},',
      'затрачено часов:', f'{spent_hour},', 'среднее время выполнения', average_spent_time, 'часа.')
