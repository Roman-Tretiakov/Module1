name = 'Roma'
print('Name: ' + name)

age = 42
print('Age: ' + str(age))

age += 1
print('New Age: ' + str(age))

is_student = True
print('Is Student: ' + str(is_student))
